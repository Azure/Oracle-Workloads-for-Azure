# Frequently Asked Questions

## Will I be charged Azure usage?

*Yes, this solution will create an Azure VM and you will be charged for VM uptime and Azure Storage.*
